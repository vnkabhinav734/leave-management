package com.leave.dao;

import com.leave.dto.EmployeeLogs;

import java.util.List;

public interface EmployeeLogsDAO {
	
	public List<EmployeeLogs> getEmployeeLogs();

}
