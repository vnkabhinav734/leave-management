package com.leave.dto;

public class KeyValue {
	 
	private String Key;
	private String Value;
	public String getKey() {
		return Key;
	}
	public void setKey(String key) {
		Key = key;
	}
	public String getValue() {
		return Value;
	}
	public void setValue(String value) {
		Value = value;
	} 
	 
}
