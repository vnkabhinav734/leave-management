package com.leave.dto;

public class Salarymaster {
	
	private int EmpID;
	private int BasicPay;
	private int SpecialAllowance;
	private int HRA;
	private int MedicalAllowance;
	private int ConveyanceAllowance;
	private int TelephoneAllowance;
	private int PFDeductionEmployee;
	private int PFDeductionEmployer;
	private int CTC;
	private String PayPeriodType;
	
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public int getBasicPay() {
		return BasicPay;
	}
	public void setBasicPay(int basicPay) {
		BasicPay = basicPay;
	}
	public int getSpecialAllowance() {
		return SpecialAllowance;
	}
	public void setSpecialAllowance(int specialAllowance) {
		SpecialAllowance = specialAllowance;
	}
	public int getHRA() {
		return HRA;
	}
	public void setHRA(int hRA) {
		HRA = hRA;
	}
	public int getMedicalAllowance() {
		return MedicalAllowance;
	}
	public void setMedicalAllowance(int medicalAllowance) {
		MedicalAllowance = medicalAllowance;
	}
	public int getConveyanceAllowance() {
		return ConveyanceAllowance;
	}
	public void setConveyanceAllowance(int conveyanceAllowance) {
		ConveyanceAllowance = conveyanceAllowance;
	}
	public int getTelephoneAllowance() {
		return TelephoneAllowance;
	}
	public void setTelephoneAllowance(int telephoneAllowance) {
		TelephoneAllowance = telephoneAllowance;
	}
	public int getPFDeductionEmployee() {
		return PFDeductionEmployee;
	}
	public void setPFDeductionEmployee(int pFDeductionEmployee) {
		PFDeductionEmployee = pFDeductionEmployee;
	}
	public int getPFDeductionEmployer() {
		return PFDeductionEmployer;
	}
	public void setPFDeductionEmployer(int pFDeductionEmployer) {
		PFDeductionEmployer = pFDeductionEmployer;
	}
	public int getCTC() {
		return CTC;
	}
	public void setCTC(int cTC) {
		CTC = cTC;
	}
	public String getPayPeriodType() {
		return PayPeriodType;
	}
	public void setPayPeriodType(String payPeriodType) {
		PayPeriodType = payPeriodType;
	}
	
	
	
	
	

}
