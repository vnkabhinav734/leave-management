package com.leave.dto;

public class Workedunits {
	
	private int EmpID;
	private String Period;
	private String Month;
	private int TotalUnits;
	private int WorkedUnits;
	private int LeaveUnits;
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String getPeriod() {
		return Period;
	}
	public void setPeriod(String period) {
		Period = period;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public int getTotalUnits() {
		return TotalUnits;
	}
	public void setTotalUnits(int totalUnits) {
		TotalUnits = totalUnits;
	}
	public int getWorkedUnits() {
		return WorkedUnits;
	}
	public void setWorkedUnits(int workedUnits) {
		WorkedUnits = workedUnits;
	}
	public int getLeaveUnits() {
		return LeaveUnits;
	}
	public void setLeaveUnits(int leaveUnits) {
		LeaveUnits = leaveUnits;
	}
	
	

}
